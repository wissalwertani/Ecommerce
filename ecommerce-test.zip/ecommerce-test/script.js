let cart = [];

function addToCart(item, price) {
  cart.push({ item, price });
  displayCart();
}

function displayCart() {
  let cartDiv = document.getElementById("cart-items");
  if (cart.length === 0) {
    cartDiv.innerHTML = "<p>No items yet.</p>";
  } else {
    let list = "<ul>";
    let total = 0;
    cart.forEach((c) => {
      list += `<li>${c.item} - QAR ${c.price}</li>`;
      total += c.price;
    });
    list += "</ul><p><b>Total: QAR " + total + "</b></p>";
    cartDiv.innerHTML = list;
  }
}

function submitOrder(e) {
  e.preventDefault();
  alert("✅ Order placed successfully! (Demo only)");
  cart = [];
  displayCart();
}
